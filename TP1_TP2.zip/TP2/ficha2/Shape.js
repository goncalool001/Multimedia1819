"use strict";

class Shape {
	constructor(x, y) //define coordenadas da forma
	{
		this.x = x;
		this.y = y;
	}
    
	toString()
	{
		return "(" + this.x + ", " + this.y + ")";
	}
}

class Rectangle extends Shape{
	constructor(x,y,c,l,x1,y1){
		super(x,y);
		this.c = c;
		this.l = l;
	}

	draw(ctx){
		ctx.fillStyle = "#FF0000";
		ctx.fillRect(this.x,this.y,this.c,this.l);
	}
}

class Circle extends Shape{
	constructor(x,y,r,c,l,x1,y1){
		super(x,y);
		this.r = r;
		this.c = 2*r;
		this.l = this.c;
	}

	draw(ctx){
		ctx.fillStyle = "#0000FF";
		ctx.beginPath();
		ctx.arc(this.x,this.y,this.r,0,2*Math.PI);
		ctx.fill();
	}
}