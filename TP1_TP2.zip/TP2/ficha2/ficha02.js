"use strict";

(function()
{
	//automatically called as soon as the javascript is loaded
	window.addEventListener("load", main);
}());


function main()
{
	var canvas = document.getElementById("myCanvas");
	var ctx = canvas.getContext("2d");
	var cw = canvas.width;
	var ch = canvas.height;
	var n = 20;
	var shapes = [];
	var intersections,inclusions;
	randomize(n,ctx,shapes);
	gets_left_corner(shapes);
	inclusions = inclusions_counter(shapes);
	intersections = intersection_counter(shapes);
	console.log("Número de inclusões: "+inclusions);
	console.log("Número de interseções: "+(intersections-inclusions));
}


function gets_left_corner(shapes){
	var i;
	for(i=0;i<shapes.length;i++){
		if(shapes[i] instanceof Circle){
			shapes[i].x1 = shapes[i].x-shapes[i].r;
			shapes[i].y1 = shapes[i].y-shapes[i].r;
		}
		else{
			shapes[i].x1 = shapes[i].x;
			shapes[i].y1 = shapes[i].y;
		}
	}
}

function randomize(n,ctx,shapes)
{
	var i,res,x,y,c,l,r,rect,circ,MaxDimC = 60,MaxDimL = 60,MaxDimD = 50;
	for(i=0;i<n;i++){
		res = Math.random();
		x = Math.random()*600;
		y = Math.random()*600;
		if(res<=0.5){ // rectangulos
			c = 10 + Math.random()*50;
			l = 10 + Math.random()*50;
			if((x+c<600)&&(x-c>0)&&(y+l<600)&&(y-l>0)){
				rect = new Rectangle(x,y,c,l);
				shapes.push(rect);
				rect.draw(ctx);
			}
			else{
				i--;
			}
		}

		else{ // circulos
			r = 15 + Math.random()*10;
			if((x+r<600)&&(x-r>0)&&(y+r<600)&&(y-r>0)){
				circ = new Circle(x,y,r);
				shapes.push(circ);
				circ.draw(ctx);
			}
			else{
				i--;
			}
		}
	}
}

function inclusions_counter(shapes){
	var i,j,left_i,right_i,top_i,bottom_i,left_j,right_j,top_j,bottom_j;
	var inclusions = 0;
	for(i=0;i<shapes.length;i++){
		left_i = shapes[i].x1;
		right_i = shapes[i].x1 + shapes[i].c;
		top_i = shapes[i].y1;
		bottom_i = shapes[i].y1 + shapes[i].l;
		for(j=0;j<shapes.length;j++){;
			left_j = shapes[j].x1;
			right_j = shapes[j].x1 + shapes[j].c;
			top_j = shapes[j].y1;
			bottom_j = shapes[j].y1 + shapes[j].l;
			if(top_i<top_j && bottom_i>bottom_j && left_i<left_j && right_i>right_j){
				if(i!=j){
					inclusions++;
				}
			}

		}
	}
	return inclusions;
}



function intersection_counter(shapes){
	var i,j,left_i,right_i,top_i,bottom_i,left_j,right_j,top_j,bottom_j;
	var intersections = 0;
	
	for(i=0;i<shapes.length;i++){
		left_i = shapes[i].x1;
		right_i = shapes[i].x1 + shapes[i].c;
		top_i = shapes[i].y1;
		bottom_i = shapes[i].y1 + shapes[i].l;
		for(j=i;j<shapes.length;j++){
			left_j = shapes[j].x1;
			right_j = shapes[j].x1 + shapes[j].c;
			top_j = shapes[j].y1;
			bottom_j = shapes[j].y1 + shapes[j].l;
			if(Math.max(left_i, left_j) < Math.min(right_i, right_j) && Math.max(top_i, top_j) < Math.min(bottom_i, bottom_j)){
				if(i!=j){
					intersections++;
				}
			}
		}
	}
	return (intersections);
}
