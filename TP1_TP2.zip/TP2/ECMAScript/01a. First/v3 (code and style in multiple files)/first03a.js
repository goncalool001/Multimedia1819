(function()
{
	//automatically called as soon as the javascript is loaded
	window.addEventListener("load", main);
}());


function main()
{
	var button = window.document.getElementById("nameBtn");
	button.style.cursor = "pointer";
	button.addEventListener("click", nameBtnClicked);
	//console.log("main");
}
