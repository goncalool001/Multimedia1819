"use strict";

function nameBtnClicked()
{
	var name = document.getElementById("inputBox");

	window.document.getElementById("output").innerHTML = "Hello " +  name.value + "!";	
}
