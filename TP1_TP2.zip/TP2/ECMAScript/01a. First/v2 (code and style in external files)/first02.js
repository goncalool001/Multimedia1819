(function()
{
	//automatically called when javascript is loaded
	window.addEventListener("load", main);
}());


function main()
{
	var button = window.document.getElementById("nameBtn");
	button.style.cursor = "pointer";
	button.addEventListener("click", nameBtnClicked);
	//console.log("main");
}

function nameBtnClicked()
{
	var name = window.document.getElementById("inputBox");

	window.document.getElementById("output").innerHTML = "Hello " +  name.value + "!";			
}