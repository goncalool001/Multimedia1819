(function()
{
	//automatically called as soon as the javascript is loaded
	window.addEventListener("load", main);
}());


function main()
{
	var canvas = document.getElementById("myCanvas");
	var ctx = canvas.getContext("2d");
	draw(ctx);
}


function draw(ctx)
{
	ctx.fillStyle = "#339933";
	ctx.fillRect(50, 30, 150, 75);	
}
