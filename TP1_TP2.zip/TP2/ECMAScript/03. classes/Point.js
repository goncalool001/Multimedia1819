"use strict";

class Point 
{
	constructor(x, y) 
	{
		this.x = x;
		this.y = y;
	}
    
	static distance(p1, p2) 
	{
		const dx = p1.x - p2.x;
		const dy = p1.y - p2.y;
		console.log("static dist");

		return Math.sqrt(dx*dx + dy*dy);
    }

	distance(p) 
	{
		const dx = this.x - p.x;
		const dy = this.y - p.y;
		console.log("unstatic distance");

		return Math.sqrt(dx*dx + dy*dy);
    }


    toString() 
    {
    	return '(' + this.x + ', ' + this.y + ')';
    }
}
    
class ColorPoint extends Point 
{
	constructor(x, y, color) 
	{
		super(x, y);
		this.color = color;
	}
	
	toString()
	{
		return super.toString() + '; ' + this.color;
	}
}