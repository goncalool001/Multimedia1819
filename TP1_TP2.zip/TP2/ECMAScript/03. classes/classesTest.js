"use strict";

(function()
{
	window.addEventListener("load", main);
}());

function main()
{
	var cp = new ColorPoint(20, 20, 'azul');
	var p = new Point(10, 10);

	console.log(cp.toString()); // (20, 20); azul
	console.log(p.toString()); // (10, 10)

	cp.x = 25;
	cp.y = 25;
	console.log(cp.toString()); // (25, 8); green
	var d1 = Point.distance(cp, p);
	console.log(d1); // 15.132745950421556

	var d2 = cp.distance(p);
	console.log(d2); // 15.132745950421556	

	console.log(cp instanceof ColorPoint); // true
	console.log(cp instanceof Point); // true

	var prop = "x";
	console.log(p[prop]);	
}
