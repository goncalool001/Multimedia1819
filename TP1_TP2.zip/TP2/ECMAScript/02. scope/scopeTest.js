"use strict";

var n = 2;

main();

function main()
{
	{
		let n = 3; 
		console.log(n);
	}
	console.log(n);
	b = 3;
}